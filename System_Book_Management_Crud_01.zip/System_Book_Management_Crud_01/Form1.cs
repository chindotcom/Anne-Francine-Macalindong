﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace System_Book_Management_Crud_01
{
    public partial class bttnSeach : Form
    {
        MySqlConnection conn = new MySqlConnection("server=localhost;database=book_management;uid=root;pwd=12345;");
        MySqlCommand cmd;
        MySqlDataAdapter adapter;
        DataTable dt = new DataTable();


        public bttnSeach()
        {
            InitializeComponent();
         

        }
       

        private void bttnAdd_Click(object sender, EventArgs e)
        {
            if (txtTitle.Text == "" || txtAuthor.Text == "" || txtYear.Text == "" || txtGenre.Text == "")
            {
                MessageBox.Show("Please fill all fields!");
                return;
            }

            using (MySqlConnection con = new MySqlConnection("server=localhost;user id=root;password=12345;database=book_management;"))
            {
                string query = "INSERT INTO books (title, author, year, genre) VALUES (@title, @author, @year, @genre)";
                MySqlCommand cmd = new MySqlCommand(query, con);
                cmd.Parameters.AddWithValue("@title", txtTitle.Text);
                cmd.Parameters.AddWithValue("@author", txtAuthor.Text);
                cmd.Parameters.AddWithValue("@year", txtYear.Text);
                cmd.Parameters.AddWithValue("@genre", txtGenre.Text);

                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();

                MessageBox.Show("Book added successfully!");
                ClearFields();
            }

        }

        private void BttnView_Click(object sender, EventArgs e)
        {
            using (MySqlConnection con = new MySqlConnection("server=localhost;user id=root;password=12345;database=book_management;"))
            {
                string query = "SELECT * FROM books";
                MySqlDataAdapter da = new MySqlDataAdapter(query, con);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = dt;
            }
        }

        private void bttnUpdate_Click(object sender, EventArgs e)
        {
            if (txtID.Text == "")
            {
                MessageBox.Show("Select a record to update first!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string connectionString = "server=localhost;user id=root;password=12345;database=book_management;";

            using (MySqlConnection con = new MySqlConnection(connectionString))
            {
                try
                {
                    string query = "UPDATE books SET title=@title, author=@author, year=@year, genre=@genre WHERE id=@id";

                    using (MySqlCommand cmd = new MySqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@title", txtTitle.Text);
                        cmd.Parameters.AddWithValue("@author", txtAuthor.Text);
                        cmd.Parameters.AddWithValue("@year", txtYear.Text);
                        cmd.Parameters.AddWithValue("@genre", txtGenre.Text);
                        cmd.Parameters.AddWithValue("@id", txtID.Text); 

                        con.Open();
                        int rows = cmd.ExecuteNonQuery();
                        con.Close();

                        if (rows > 0)
                        {
                            MessageBox.Show("Book updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            ClearFields();
                        }
                        else
                        {
                            MessageBox.Show("No record found to update.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
                txtID.Text = row.Cells["id"].Value.ToString();
                txtTitle.Text = row.Cells["title"].Value.ToString();
                txtAuthor.Text = row.Cells["author"].Value.ToString();
                txtYear.Text = row.Cells["year"].Value.ToString();
                txtGenre.Text = row.Cells["genre"].Value.ToString();
            }
        }
        private void ClearFields()
        {
            txtID.Clear();
            txtTitle.Clear();
            txtAuthor.Clear();
            txtYear.Clear();
            txtGenre.Clear();
        }

        private void bttnDelete_Click(object sender, EventArgs e)
        {
            if (txtID.Text == "")
            {
                MessageBox.Show("Select a record to delete.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DialogResult result = MessageBox.Show("Are you sure you want to delete this record?",
                                                  "Confirm Delete",
                                                  MessageBoxButtons.YesNo,
                                                  MessageBoxIcon.Question);

            if (result == DialogResult.No)
                return;

            try
            {
                string connectionString = "server=localhost;user id=root;password=12345;database=book_management;";

                using (MySqlConnection con = new MySqlConnection(connectionString))
                {
                    string query = "DELETE FROM books WHERE id = @id";
                    using (MySqlCommand cmd = new MySqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@id", txtID.Text);

                        con.Open();
                        int rowsAffected = cmd.ExecuteNonQuery();
                        con.Close();

                        if (rowsAffected > 0)
                            MessageBox.Show("Book deleted successfully!s", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        else
                            MessageBox.Show("No record found with that ID.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }

                ClearFields();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void txtID_TextChanged(object sender, EventArgs e)
        {

        }

        private void guna2Button1_Click_1(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show(
               "Are you sure you want to log out?",
               "Logout Confirmation",
               MessageBoxButtons.YesNo,
               MessageBoxIcon.Question
           );

            if (result == DialogResult.Yes)
            {
                Login_Form login = new Login_Form();
                login.Show();
                this.Close();
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void bttnsearch_Click(object sender, EventArgs e)
        {
            string connectionString = "server=localhost;user id=root;password=12345;database=book_management;";
            string keyword = textSearch.Text.Trim();

            if (keyword == "")
            {
                MessageBox.Show("Please enter a search keyword.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            try
            {
                using (MySqlConnection con = new MySqlConnection(connectionString))
                {
                    string query = @"SELECT * FROM books 
                             WHERE title LIKE @keyword 
                             OR author LIKE @keyword 
                             OR year LIKE @keyword 
                             OR genre LIKE @keyword";

                    using (MySqlCommand cmd = new MySqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@keyword", "%" + keyword + "%");

                        MySqlDataAdapter adapter = new MySqlDataAdapter(cmd);
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);

                        dataGridView1.DataSource = dt;

                        if (dt.Rows.Count == 0)
                        {
                            MessageBox.Show("No matching records found.", "Search Result", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
    }
    
    
    
   
}
    


    
    

